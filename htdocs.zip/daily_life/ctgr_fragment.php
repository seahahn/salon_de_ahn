
    <select class="custom-select col-8 mr-2" name="category" <?php if(isset($_GET['num'])) echo 'disabled';?>>
        <?php
        if(isset($_POST['category'])){ // 글 읽기 상태에서 글쓰기 누른 경우. 읽던 글의 카테고리 선택하게 함
        ?>
        <option disabled>게시판 분류</option>
        <option <?php if($category == 'finance') echo 'selected'?> value="finance">finance</option>
        <option <?php if($category == 'language') echo 'selected'?> value="language">language</option>
        <option <?php if($category == 'it_dev') echo 'selected'?> value="it_dev">it_dev</option>
        <option <?php if($category == 'daily_life') echo 'selected'?> value="daily_life">daily_life</option>
        <?php                                                                
        } else if(isset($_GET['num'])) { // 글 읽기 상태에서 답글 누른 경우. 읽던 글의 카테고리 선택 후 고정되게 함
        ?>
        <option selected value="<?=$category?>"><?=$category?></option>
        <!-- <?php
            switch ($category){
                case 'finance': 
        ?>
            <option selected value="finance">finance</option>
            <?php
                break;                                                                    
                case 'language':
            ?>
            <option selected value="language">language</option>
            <?php
                break;                                                                    
                case 'it_dev':
            ?>
            <option selected value="it_dev">it_dev</option>
            <?php
                break;                                                                    
                case 'it_dev':
            ?>
            <option selected value="daily_life">daily_life</option>
            <?php
                break;
                default : break;
            }
            ?>                                                                 -->
        <?php
        } else { // 그 외 경우. ex) 마이페이지 내가 쓴 글 목록에서 글쓰기 누른 경우 등
        ?>
        <option selected>게시판 분류</option>
        <option value="finance">finance</option>
        <option value="language">language</option>
        <option value="it_dev">it_dev</option>
        <option value="daily_life">daily_life</option>
        <?php
        }
        ?>
    </select>
    <select class="custom-select col" name="headpiece" <?php if(isset($_GET['num'])) echo 'disabled';?>>
        <option selected>말머리</option>
        <option value="1">One</option>
        <option value="2">Two</option>
        <option value="3">Three</option>
    </select>