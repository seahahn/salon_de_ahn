<div class="container">
    <div class="row">						

    </div>    
    <div class="row">
        <div class="col-12">

            <!-- Contact -->
                <section class="contact">
                    <header>
                        <h3>Contact</h3>
                    </header>                                        
                    <p>salon.de.ahn@gmail.com</p>                                   
                </section>

            <!-- Copyright -->
                <div class="copyright">
                    <ul class="menu">
                        <li><a href="#">Sitemap</a></li>
                        <li>&copy; Salon de Ahn. All rights reserved.</li>
                        <li>Design: <a href="http://html5up.net">HTML5 UP</a></li>
                    </ul>
                </div>

        </div>

    </div>
</div>