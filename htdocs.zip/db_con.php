<?php
    $db_id="root";
    $db_pw="0121";
    $db_name="salon_de_ahn";
    $db_domain="127.0.0.1";
    $db=mysqli_connect($db_domain,$db_id,$db_pw,$db_name);

    function mq($sql){
        global $db;
        return $db->query($sql);
    }
?>