
    <select class="custom-select col-8 mr-2" name="category" <?php if(isset($_GET['num'])) echo 'disabled';?>>
        <?php
        if(isset($_POST['category'])){ // 글 읽기 상태에서 글쓰기 누른 경우. 읽던 글의 카테고리 선택하게 함
        ?>
        <option disabled>게시판 분류</option>
        <option disabled>- IT 개발 -</option>
        <?php
        if($role == "ADMIN") {
        ?>
        <option <?php if($category == 'it_dev_learnings') echo 'selected'?> value="it_dev_learnings">학습 내용</option>
        <option <?php if($category == 'it_dev_usefulinfo') echo 'selected'?> value="it_dev_usefulinfo">유용한 정보</option>
        <?php }?>
        <option <?php if($category == 'it_dev_discussion') echo 'selected'?> value="it_dev_discussion">토론</option>
        <option <?php if($category == 'it_dev_recordshare') echo 'selected'?> value="it_dev_recordshare">경험 공유</option>
        <option <?php if($category == 'it_dev_infoshare') echo 'selected'?> value="it_dev_infoshare">정보 공유</option>
        <option <?php if($category == 'it_dev_qna') echo 'selected'?> value="it_dev_qna">Q & A</option>
        <option disabled></option>
        <option disabled>- 금융 -</option>
        <?php
        if($role == "ADMIN") {
        ?>
        <option <?php if($category == 'finance_usefulinfo') echo 'selected'?> value="finance_usefulinfo">유용한 정보</option>
        <?php }?>
        <option <?php if($category == 'finance_discussion') echo 'selected'?> value="finance_discussion">토론</option>
        <option <?php if($category == 'finance_recordshare') echo 'selected'?> value="finance_recordshare">거래 기록 공유</option>
        <option <?php if($category == 'finance_infoshare') echo 'selected'?> value="finance_infoshare">정보 공유</option>
        <option <?php if($category == 'finance_qna') echo 'selected'?> value="finance_qna">Q & A</option>
        <option disabled></option>
        <option disabled>- 언어 학습 -</option>
        <?php
        if($role == "ADMIN") {
        ?>
        <option <?php if($category == 'languages_usefuldata') echo 'selected'?> value="languages_usefuldata">학습 자료</option>        
        <?php }?>
        <option <?php if($category == 'languages_discussion') echo 'selected'?> value="languages_discussion">토론</option>
        <option <?php if($category == 'languages_recordshare') echo 'selected'?> value="languages_recordshare">학습 기록</option>
        <option <?php if($category == 'languages_infoshare') echo 'selected'?> value="languages_infoshare">정보 공유</option>
        <option <?php if($category == 'languages_qna') echo 'selected'?> value="languages_qna">Q & A</option>
        <option disabled></option>
        <option disabled>- 일상 -</option>
        <?php
        if($role == "ADMIN") {
        ?>
        <option <?php if($category == 'daily_life') echo 'selected'?> value="daily_life">일상 기록</option>
        <?php }?>
        <option <?php if($category == 'daily_life_share') echo 'selected'?> value="daily_life_share">자유 주제 글</option>

        <?php                                                                
        } else if(isset($_GET['num'])) { // 글 읽기 상태에서 답글 누른 경우. 읽던 글의 카테고리 선택 후 고정되게 함
        ?>
        <option selected value="<?=$category?>"><?=$category?></option>
        <!-- <?php
            switch ($category){
                case 'finance': 
        ?>
            <option selected value="finance">finance</option>
            <?php
                break;                                                                    
                case 'language':
            ?>
            <option selected value="language">language</option>
            <?php
                break;                                                                    
                case 'it_dev':
            ?>
            <option selected value="it_dev">it_dev</option>
            <?php
                break;                                                                    
                case 'it_dev':
            ?>
            <option selected value="daily_life">daily_life</option>
            <?php
                break;
                default : break;
            }
            ?>                                                                 -->
        <?php
        } else { // 그 외 경우. ex) 마이페이지 내가 쓴 글 목록에서 글쓰기 누른 경우 등
        ?>
        <option selected>게시판 분류</option>
        <option value="finance">finance</option>
        <option value="language">language</option>
        <option value="it_dev">it_dev</option>
        <option value="daily_life">daily_life</option>
        <?php
        }
        ?>
    </select>
    <select class="custom-select col" name="headpiece" <?php if(isset($_GET['num'])) echo 'disabled';?>>
        <option selected>말머리</option>
        <option value="1">One</option>
        <option value="2">Two</option>
        <option value="3">Three</option>
    </select>